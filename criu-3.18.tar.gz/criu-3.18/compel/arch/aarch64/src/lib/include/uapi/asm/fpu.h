#ifndef __CR_ASM_FPU_H__
#define __CR_ASM_FPU_H__

#endif /* __CR_ASM_FPU_H__ */
