#ifndef COMPEL_PLUGIN_STD_FDS_H__
#define COMPEL_PLUGIN_STD_FDS_H__

#include <sys/un.h>
#include <compel/common/scm.h>

#endif /* COMPEL_PLUGIN_STD_FDS_H__ */
