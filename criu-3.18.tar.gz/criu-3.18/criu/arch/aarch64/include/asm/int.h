#ifndef __CR_ASM_INT_H__
#define __CR_ASM_INT_H__

#include "asm-generic/int.h"

#endif /* __CR_ASM_INT_H__ */
