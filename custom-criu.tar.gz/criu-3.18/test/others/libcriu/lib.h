void what_err_ret_mean(int ret);
int chk_exit(int status, int want);
int get_version(void);

#define SUCC_ECODE 42
